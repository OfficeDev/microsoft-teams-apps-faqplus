﻿
// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Not required to catch specific exception.", Scope = "member", Target = "~M:Microsoft.Teams.Apps.FAQPlusPlus.Configuration.Controllers.HomeController.RefreshQnAMakerEndpointKeyAsync~System.Threading.Tasks.Task{System.Boolean}")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Not required to catch specific exception.", Scope = "member", Target = "~M:Microsoft.Teams.Apps.FAQPlusPlus.Configuration.Controllers.HomeController.IsKnowledgeBaseIdValid(System.String)~System.Threading.Tasks.Task{System.Boolean}")]

